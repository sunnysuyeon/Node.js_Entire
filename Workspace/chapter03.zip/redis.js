const redis = require('redis');
const client = redis.createClient();

console.log(1);
client.connect()
console.log(2);
client.set('name', 'zaaeraaaocho');
console.log(3);
// 값을 가져옴
client.get('name', (err, reply) => {
    console.log(reply); // zerocho
});
console.log(5);
