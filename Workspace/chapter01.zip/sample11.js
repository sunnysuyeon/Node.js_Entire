function wait(sec) {
    this.secc = sec;
    console.log(this.secc);
}

class waitCls{
    constructor(sec){
        this.secc = sec;
        console.log(this.secc);
    }
}
// 아래 2줄은 같다.
let wait1 = new wait(1);
let wait2 = new waitCls(1);