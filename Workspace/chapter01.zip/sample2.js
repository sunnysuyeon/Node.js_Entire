const country = {
    name: "Korea",
    population: "5178579",
    get_name: function (a) {
        return a + 3;
    }
};

const animal = ['dog', 'cat'];
let [first, second] = animal;
console.log(animal);
console.log(animal[0]);
console.log(animal[1]);
console.log(first);
console.log(second);

