const request = require('request');
const express = require('express');
const app = express();
var client_id = '1OROfOeTkxi7UAx1F8_k';
var client_secret = '6cT1O_dtxx';
var api_url = 'https://openapi.naver.com/v1/datalab/search';

/* 포트 설정 */
app.set('port', process.env.PORT || 8080);

/* 공통 미들웨어 */
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* 라우팅 설정 */
app.get('/naver/search', (req, res) => {

});

/* 서버와 포트 연결.. */
app.listen(app.get('port'), () => {
    console.log(app.get('port'), '번 포트에서 서버 실행 중 ..')
});
// ===========================================위쪽 코딩
