const express = require('express');
const app = express()

app.get('/', (req, res) => {
    console.log(req.query);
    
    res.send('Hello World! GET');
});

app.delete('/', (req, res) => {
    res.send('Hello World! POST');
});

app.listen(8080, () =>
    console.log('8080포트에서 서버 실행중'));

