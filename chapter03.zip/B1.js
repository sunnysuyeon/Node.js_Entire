/* B1.js */

const A = require('./A1');
const B = 'variable B from B1.js';

console.log(A + ' in B1.js');

module.exports = B;
