
console.log(add1(1,2));
console.log(add2);

function add1(a, b) {
    return a+b;
}
var add2 = function(a, b){
    return a+b;
}
let add3 = function(a, b){
    return a+b;
}


console.log(add3(1,2));
