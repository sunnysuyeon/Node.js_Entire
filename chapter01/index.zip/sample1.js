let puppy = 'cute';
console.log(puppy);
{
    let puppy = 'so cute';
    console.log(puppy);
}
console.log(puppy);
